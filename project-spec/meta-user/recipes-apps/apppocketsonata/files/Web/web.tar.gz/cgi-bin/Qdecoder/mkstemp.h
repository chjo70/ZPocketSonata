

// #include "leafnode.h"


int mkstemp (char *tmpl);


